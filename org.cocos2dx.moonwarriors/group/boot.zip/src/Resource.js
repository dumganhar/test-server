var res = {
    bgMusic_mp3: 'group/gamelayer/res/Music/bgMusic.mp3',
    bgMusic_ogg: 'group/gamelayer/res/Music/bgMusic.ogg',
    buttonEffet_mp3: 'group/boot/res/Music/buttonEffet.mp3',
    buttonEffet_ogg: 'group/boot/res/Music/buttonEffet.ogg',
    explodeEffect_mp3: 'group/gamelayer/res/Music/explodeEffect.mp3',
    explodeEffect_ogg: 'group/gamelayer/res/Music/explodeEffect.ogg',
    fireEffect_mp3: 'group/gamelayer/res/Music/fireEffect.mp3',         //unused
    fireEffect_ogg: 'group/gamelayer/res/Music/fireEffect.ogg',         //unused
    mainMainMusic_mp3: 'group/boot/res/Music/mainMainMusic.mp3',
    mainMainMusic_ogg: 'group/boot/res/Music/mainMainMusic.ogg',
    shipDestroyEffect_mp3: 'group/gamelayer/res/Music/shipDestroyEffect.mp3',
    shipDestroyEffect_ogg: 'group/gamelayer/res/Music/shipDestroyEffect.ogg',
    arial_14_fnt: 'group/gamelayer/res/arial-14.fnt',
    arial_14_png: 'group/gamelayer/res/arial-14.png',
    b01_plist: 'group/gamelayer/res/b01.plist',
    b01_png: 'group/gamelayer/res/b01.png',
    cocos2d_html5_png: 'group/gameover/res/cocos2d-html5.png',
    explode_plist: 'group/gamelayer/res/explode.plist',              //unused
    explosion_plist: 'group/gamelayer/res/explosion.plist',
    explosion_png: 'group/gamelayer/res/explosion.png',
    flare_jpg: 'group/boot/res/flare.jpg',
    gameOver_png: 'group/gameover/res/gameOver.png',
    level01_tmx: 'group/boot/res/level01.tmx',
    loading_png: 'group/boot/res/loading.png',
    logo_png: 'group/boot/res/logo.png',
    button_png: 'group/boot/res/button.png',
    buttonBackground_png: 'group/boot/res/buttonBackground.png',
    buttonHighlighted_png: 'group/boot/res/buttonHighlighted.png',
    menu_png: 'group/boot/res/menu.png',
    menuTitle_png: 'group/common/res/menuTitle.png',
    textureOpaquePack_plist: 'group/gamelayer/res/textureOpaquePack.plist',
    textureOpaquePack_png: 'group/gamelayer/res/textureOpaquePack.png',
    textureTransparentPack_plist: 'group/boot/res/textureTransparentPack.plist',
    textureTransparentPack_png: 'group/boot/res/textureTransparentPack.png'
};
window["boot"] = [
    res.loading_png,
    res.flare_jpg,
    res.button_png,
    res.buttonBackground_png,
    res.buttonHighlighted_png,
    res.menu_png,
    res.logo_png,
    res.mainMainMusic_mp3,
    res.mainMainMusic_ogg,
    res.menuTitle_png,
    res.textureTransparentPack_plist,
    res.textureTransparentPack_png
];
window["gamelayer"] = [
    //image
    res.b01_png,
    res.b01_plist,
    res.arial_14_png,
    res.explosion_png,
    res.textureOpaquePack_png,

    //tmx
    //res.level01_tmx,

    //plist
    res.explosion_plist,
    res.textureOpaquePack_plist,

    //music
    res.bgMusic_mp3,
    res.bgMusic_ogg,

    //effect
    res.buttonEffet_mp3,
    res.explodeEffect_mp3,
    res.fireEffect_mp3,
    res.shipDestroyEffect_mp3,
    res.buttonEffet_ogg,
    res.explodeEffect_ogg,
    res.fireEffect_ogg,
    res.shipDestroyEffect_ogg,

    // FNT
    res.arial_14_fnt
];
window["gameover"] = [
    res.cocos2d_html5_png,
    res.gameOver_png
]
