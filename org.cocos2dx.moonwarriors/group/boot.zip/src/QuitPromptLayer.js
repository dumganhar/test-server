        
var __isQuitPromptLayerOpened = false;
var __quitPromptLayer = null;
var __rootNode = null;

function addButton(parent, name, pos, cb) {
        // Add the button
    var backgroundButton = cc.Scale9Sprite.create("res/button.png");
    var backgroundHighlightedButton = cc.Scale9Sprite.create("res/buttonHighlighted.png");

    var titleButton = new cc.LabelTTF(name, "Marker Felt", 26);
    titleButton.color = cc.color(159, 168, 176);

    var controlButton = cc.ControlButton.create(titleButton, backgroundButton);
    controlButton.setBackgroundSpriteForState(backgroundHighlightedButton, cc.CONTROL_STATE_HIGHLIGHTED);
    controlButton.setTitleColorForState(cc.color.WHITE, cc.CONTROL_STATE_HIGHLIGHTED);

    controlButton.anchorX = 0.5;
    controlButton.anchorY = 0.5;
    controlButton.x = pos.x;
    controlButton.y = pos.y;

    controlButton.addTargetWithActionForControlEvents(this, function(){
        cb();
    }, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);

    parent.addChild(controlButton, 1);
}

function openQuitPromptLayer() {
    if (__isQuitPromptLayerOpened) {
        if (__quitPromptLayer && __rootNode) {
            __quitPromptLayer.removeFromParent();
            cc.eventManager.resumeTarget(__rootNode, true);
            __isQuitPromptLayerOpened = false;
            __quitPromptLayer = null;
            __rootNode = null;
        }
        return;
    }

    __isQuitPromptLayerOpened = true;

    var origin = cc.director.getVisibleOrigin();
    var size = cc.director.getVisibleSize();
    var rootNode = cc.director.getRunningScene();
    __rootNode = rootNode;

    cc.eventManager.pauseTarget(rootNode, true);
    var colorLayer = new cc.LayerColor(cc.color(0, 0, 0, 100));
    rootNode.addChild(colorLayer, 9999); //set colorLayer to top
    __quitPromptLayer = colorLayer;

    var oldOnExit = rootNode.onExit.bind(rootNode);
    rootNode.onExit = function() {
        oldOnExit();
        __isQuitPromptLayerOpened = false;
        __quitPromptLayer = null;
    }


   // Add the black background
    var background = cc.Scale9Sprite.create("res/buttonBackground.png");
    background.width = 300;
    background.height = 170;
    background.x = size.width / 2.0;
    background.y = size.height / 2.0;
    colorLayer.addChild(background);

    var labelPrompt = new cc.LabelTTF("残忍的离开？", "Marker Felt", 26);
    labelPrompt.color = cc.color(159, 168, 176);
    labelPrompt.x = background.width / 2;
    labelPrompt.y = background.height - 30;
    background.addChild(labelPrompt);

    addButton(background, "取消", cc.p(background.width/2 + 50, 50), function() {
        colorLayer.removeFromParent();
        cc.eventManager.resumeTarget(rootNode, true);
        __isQuitPromptLayerOpened = false;
    });

    addButton(background, "确定", cc.p(background.width/2 - 50, 50), function() {
        cc.log("call quit game....");
        cc.director.end();
    });
}
