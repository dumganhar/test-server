
var SysMenu = cc.Layer.extend({
    _ship:null,

    ctor:function () {
        this._super();
        this.init();
    },
    init:function () {
        cc.spriteFrameCache.addSpriteFrames(res.textureTransparentPack_plist);

        winSize = cc.director.getWinSize();
        var sp = new cc.Sprite(res.loading_png);
        sp.anchorX = 0;
        sp.anchorY = 0;
        sp.scale = MW.SCALE;
        this.addChild(sp, 0, 1);

        var logo = new cc.Sprite(res.logo_png);
        logo.attr({
            anchorX: 0,
            anchorY: 0,
            x: 0,
            y: MW.LOGOY,
            scale: MW.SCALE
        });
        this.addChild(logo, 10, 1);

        var newGameNormal = new cc.Sprite(res.menu_png, cc.rect(0, 0, 126, 33));
        var newGameSelected = new cc.Sprite(res.menu_png, cc.rect(0, 33, 126, 33));
        var newGameDisabled = new cc.Sprite(res.menu_png, cc.rect(0, 33 * 2, 126, 33));

        var gameSettingsNormal = new cc.Sprite(res.menu_png, cc.rect(126, 0, 126, 33));
        var gameSettingsSelected = new cc.Sprite(res.menu_png, cc.rect(126, 33, 126, 33));
        var gameSettingsDisabled = new cc.Sprite(res.menu_png, cc.rect(126, 33 * 2, 126, 33));

        var aboutNormal = new cc.Sprite(res.menu_png, cc.rect(252, 0, 126, 33));
        var aboutSelected = new cc.Sprite(res.menu_png, cc.rect(252, 33, 126, 33));
        var aboutDisabled = new cc.Sprite(res.menu_png, cc.rect(252, 33 * 2, 126, 33));
        var flare = new cc.Sprite(res.flare_jpg);
        this.addChild(flare, 15, 10);
        flare.visible = false;
        var newGame = new cc.MenuItemSprite(newGameNormal, newGameSelected, newGameDisabled, function () {
            this.onButtonEffect();
            //this.onNewGame();
            flareEffect(flare, this, this.onNewGame);
        }.bind(this));
        var gameSettings = new cc.MenuItemSprite(gameSettingsNormal, gameSettingsSelected, gameSettingsDisabled, this.onSettings, this);
        var about = new cc.MenuItemSprite(aboutNormal, aboutSelected, aboutDisabled, this.onAbout, this);
        newGame.scale = MW.SCALE;
        gameSettings.scale = MW.SCALE;
        about.scale = MW.SCALE;

        var menu = new cc.Menu(newGame, gameSettings, about);
        menu.alignItemsVerticallyWithPadding(10);
        this.addChild(menu, 1, 2);
        menu.x = winSize.width / 2;
        menu.y = winSize.height / 2 - 80;
        this.schedule(this.update, 0.1);

        this._ship = new cc.Sprite("#ship03.png");
        this.addChild(this._ship, 0, 4);
        this._ship.x = Math.random() * winSize.width;
        this._ship.y = 0;
        this._ship.runAction(cc.moveBy(2, cc.p(Math.random() * winSize.width, this._ship.y + winSize.height + 100)));

        if (MW.SOUND) {
            cc.audioEngine.setMusicVolume(0.7);
            cc.audioEngine.playMusic(res.mainMainMusic_mp3, true);
        }

        return true;
    },
    onNewGame:function (pSender) {
        //load resources
        var self = this;
        var cb = function(isSucceed) {
            cc.log("onNewGame callback: " + isSucceed);
            if (isSucceed) {
                cc.audioEngine.stopMusic();
                cc.audioEngine.stopAllEffects();
                var scene = new cc.Scene();
                scene.addChild(new GameLayer());
                scene.addChild(new GameControlMenu());
                cc.director.runScene(new cc.TransitionFade(1.2, scene));
            } else {
                showDownloadGroupFailedDialog("gamelayer", cb, self);
            }
        };

        cc.LoaderScene.preload("gamelayer", cb, self);
    },
    onSettings:function (pSender) {
        this.onButtonEffect();
        var self = this;
        var cb = function(isSucceed) {
            if (isSucceed) {
                var scene = new cc.Scene();
                scene.addChild(new SettingsLayer());
                cc.director.runScene(new cc.TransitionFade(1.2, scene));
            } else {
                showDownloadGroupFailedDialog("common", cb, self);
            }
        };
        cc.LoaderScene.preload("common", cb, self);
    },
    onAbout:function (pSender) {
        this.onButtonEffect();
        var self = this;
        var cb = function(isSucceed) {
            if (isSucceed) {
                var scene = new cc.Scene();
                scene.addChild(new AboutLayer());
                cc.director.runScene(new cc.TransitionFade(1.2, scene));
            } else {
                showDownloadGroupFailedDialog("common", cb, self);
            }
        };
        cc.LoaderScene.preload("common", cb, self);
    },
    update:function () {
        if (this._ship.y > 750) {
            this._ship.x = Math.random() * winSize.width;
	        this._ship.y = 10;
            this._ship.runAction(cc.moveBy(
                parseInt(5 * Math.random(), 10),
                cc.p(Math.random() * winSize.width, this._ship.y + 750)
            ));
        }
    },
    onButtonEffect:function(){
        if (MW.SOUND) {
            var s = cc.audioEngine.playEffect(res.buttonEffet_mp3);
        }
    }
});

SysMenu.scene = function () {
    var scene = new cc.Scene();
    var layer = new SysMenu();
    scene.addChild(layer);
    return scene;
};

var getNativeKeyName = function(keyCode) {
    var allCode = Object.getOwnPropertyNames(cc.KEY);
    var keyName = "";
    for(var x in allCode){
        if(cc.KEY[allCode[x]] == keyCode){
            keyName = allCode[x];
            break;
        }
    }
    return keyName;
};

var registerKeyEvent = function() {

    cc.eventManager.addListener({
        event: cc.EventListener.KEYBOARD,
        onKeyReleased: function(keyCode, event){
            cc.log("Key " + (cc.sys.isNative ? getNativeKeyName(keyCode) : String.fromCharCode(keyCode) ) + "(" + keyCode.toString()  + ") was released!");
            if (cc.sys.isNative) {
                var keyName = getNativeKeyName(keyCode);
                if (keyName == "back" || keyName == "backspace") {
                    cc.log("Back key was released!");
                    openQuitPromptLayer();
                }
            }
        }
    }, -1);
};

registerKeyEvent();

function addButtonToNetworkErrorDialog(parent, name, pos, cb) {
        // Add the button
    var backgroundButton = cc.Scale9Sprite.create("res/button.png");
    var backgroundHighlightedButton = cc.Scale9Sprite.create("res/buttonHighlighted.png");

    var titleButton = new cc.LabelTTF(name, "Marker Felt", 26);
    titleButton.color = cc.color(159, 168, 176);

    var controlButton = cc.ControlButton.create(titleButton, backgroundButton);
    controlButton.setBackgroundSpriteForState(backgroundHighlightedButton, cc.CONTROL_STATE_HIGHLIGHTED);
    controlButton.setTitleColorForState(cc.color.WHITE, cc.CONTROL_STATE_HIGHLIGHTED);

    controlButton.anchorX = 0.5;
    controlButton.anchorY = 0.5;
    controlButton.x = pos.x;
    controlButton.y = pos.y;

    controlButton.addTargetWithActionForControlEvents(this, function(){
        cb();
    }, cc.CONTROL_EVENT_TOUCH_UP_INSIDE);

    parent.addChild(controlButton, 1);
}

function showDownloadGroupFailedDialog(groupName, cb, target) {

    var origin = cc.director.getVisibleOrigin();
    var size = cc.director.getVisibleSize();
    var rootNode = cc.director.getRunningScene();

    cc.eventManager.pauseTarget(rootNode, true);
    var colorLayer = new cc.LayerColor(cc.color(0, 0, 0, 100));
    rootNode.addChild(colorLayer, 9999); //set colorLayer to top


   // Add the black background
    var background = cc.Scale9Sprite.create("res/buttonBackground.png");
    background.width = 300;
    background.height = 170;
    background.x = size.width / 2.0;
    background.y = size.height / 2.0;
    colorLayer.addChild(background);

    var labelPrompt = new cc.LabelTTF("网络异常，重新连接？", "Marker Felt", 26);
    labelPrompt.color = cc.color(159, 168, 176);
    labelPrompt.x = background.width / 2;
    labelPrompt.y = background.height - 30;
    background.addChild(labelPrompt);

    addButtonToNetworkErrorDialog(background, "确定", cc.p(background.width/2, 50), function() {
        colorLayer.removeFromParent();
        cc.log("retry connection!");
        cc.LoaderScene.preload(groupName, cb, target);
    });
}

